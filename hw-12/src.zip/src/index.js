import "./css/styles.css";
var debounce = require("lodash.debounce");

import fetchCountries from "./js/fetchCountries";
import searchCountryTemplate from "./templates/search-country.hbs";
import searchResultsTemplate from "./templates/search-results.hbs";

const elements = {
  input: document.getElementById("country-input"),
  resultsPage: document.getElementById("results"),
  countryPage: document.getElementById("country-page")
};

const clearOutput = () => {
  elements.countryPage.innerHTML = "";
  elements.resultsPage.innerHTML = "";
};

const delay = debounce(function() {
	if (elements.input.value === "") {
		clearOutput();
		return; //выходим из ф-ции
	}
  fetchCountries(elements.input.value).then(result => {
    if (result.length === 1) {
			clearOutput();
      elements.countryPage.insertAdjacentHTML("beforeend", buildPage(result));
    } else {
      console.log(result);
      elements.countryPage.innerHTML = "";
      elements.resultsPage.insertAdjacentHTML("beforeend",buildResults(result)
      );
    }
  });
  const buildResults = items => {
    const markup = items.map(item => searchResultsTemplate(item)).join("");
    return markup;
  };
  const buildPage = items => {
    const markup = items.map(item => searchCountryTemplate(item)).join("");
    return markup;
  };
}, 500);

elements.input.addEventListener("input", delay);
